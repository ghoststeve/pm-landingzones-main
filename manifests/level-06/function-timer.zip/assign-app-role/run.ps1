param($Timer)

if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

<#
.SYNOPSIS
    A script which uses the existing MGConnection to check for Groups which have no app role assignments.

    If the group has only one owner, and that owner is a Service Principal with a name like "AWS 3009",
    then the default app role is assigned to the group.
#>

#Get all groups which start with AWS and have no app role assignments
$filteredGroups = Get-MgGroup -All -Filter "startswith(displayName, 'aws')" -ExpandProperty AppRoleAssignments | Where-Object { $_.AppRoleAssignments.length -eq 0 }

write-host "Found $($filteredGroups.Count) groups to process"

#Check the Owners property of each group and if there is only one owner, assign the default app role to the group
foreach ($filteredGroup in $filteredGroups) {

    #Expand Owners property to get the Service Principal
    $group = Get-MgGroup -GroupId $filteredGroup.Id -ExpandProperty Owners

    if ($group.Owners.length -eq 1) {
        write-host "`tProcessing group $($group.DisplayName) with ID $($group.Id) due to Owner Count"
        #Get the assigned Service principal
        try {
            $servicePrincipal = Get-MgServicePrincipal -ServicePrincipalId $group.Owners.Id -Property AppRoles, DisplayName, Id -ErrorAction Stop
        }
        catch {
            Write-Error "`t`tError getting Service Principal for group $($group.DisplayName) with ID $($group.Id)" -ForegroundColor White -BackgroundColor Red
            continue
        }

        if ($servicePrincipal.DisplayName -match '^BA_AWS_\d+$') {
            write-host "`t`tAssigning default App Role to Group!"
            $params = @{
                principalId = $group.Id
                resourceId  = $servicePrincipal.Id
                appRoleId   = $servicePrincipal.AppRoles.Id
            }
            #write-host "`t`t`$params: $($params | ConvertTo-JSON)" -ForegroundColor Green
            New-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $servicePrincipal.Id -BodyParameter $params | ConvertTo-JSON
            
            Write-Host "`t`tAssigned default App Role to Group!"
        }
        else {
            Write-Host "`t`t[INFO] Group is not an AWS Group, skipping" -ForegroundColor Yellow
        }
    }
    else {
        Write-Host "`t[INFO] Group has unexpected number of owners, skipping" -ForegroundColor Yellow
    }
}

